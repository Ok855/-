# AdBlocker Android

Новый чистый Android-проект с VPNService-каркасом и автоматической сборкой APK через GitHub Actions.

После загрузки в GitHub:
1. Открой Actions.
2. Выбери Build APK.
3. Запусти workflow.
4. После зелёной галочки скачай `AdBlocker-debug-apk` из Artifacts.

Важно: эта версия является рабочим каркасом VPN-блокировщика. Полноценная DNS-фильтрация рекламных доменов ещё не реализована.
