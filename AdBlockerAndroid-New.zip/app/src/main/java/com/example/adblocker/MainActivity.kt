package com.example.adblocker

import android.content.Intent
import android.net.VpnService
import android.os.Bundle
import android.widget.Button
import android.widget.TextView
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity

class MainActivity : AppCompatActivity() {
    private lateinit var status: TextView
    private lateinit var toggle: Button
    private var running = false

    private val vpnPermission =
        registerForActivityResult(ActivityResultContracts.StartActivityForResult()) {
            if (it.resultCode == RESULT_OK) startBlocker()
        }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        status = findViewById(R.id.status)
        toggle = findViewById(R.id.toggle)

        toggle.setOnClickListener {
            if (running) stopBlocker()
            else {
                val intent = VpnService.prepare(this)
                if (intent != null) vpnPermission.launch(intent)
                else startBlocker()
            }
        }
    }

    private fun startBlocker() {
        startService(Intent(this, AdBlockVpnService::class.java).setAction("START"))
        running = true
        status.text = "Блокировщик включён"
        toggle.text = "Выключить"
    }

    private fun stopBlocker() {
        startService(Intent(this, AdBlockVpnService::class.java).setAction("STOP"))
        running = false
        status.text = "Блокировщик выключен"
        toggle.text = "Включить"
    }
}
