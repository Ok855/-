package com.example.adblocker

import android.content.Intent
import android.net.VpnService
import android.os.ParcelFileDescriptor

class AdBlockVpnService : VpnService() {
    private var vpn: ParcelFileDescriptor? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        when (intent?.action) {
            "START" -> startVpn()
            "STOP" -> stopVpn()
        }
        return START_NOT_STICKY
    }

    private fun startVpn() {
        if (vpn != null) return

        vpn = Builder()
            .setSession("AdBlocker")
            .addAddress("10.0.0.2", 32)
            .addRoute("0.0.0.0", 0)
            .addDnsServer("10.0.0.1")
            .establish()
    }

    private fun stopVpn() {
        vpn?.close()
        vpn = null
        stopSelf()
    }

    override fun onDestroy() {
        stopVpn()
        super.onDestroy()
    }
}
